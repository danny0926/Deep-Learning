import argparse
import itertools
import os
import random
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import bair_robot_pushing_dataset
from models.lstm import gaussian_lstm, lstm
from models.vgg_64 import vgg_decoder, vgg_encoder
from utils import init_weights, kl_criterion, finn_eval_seq, mse_metric
from utils import plot_pred, pred, save_gif_with_text
torch.backends.cudnn.benchmark = True



def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch_size', default=12, type=int, help='batch size')
    parser.add_argument('--model_dir', default='', help='base directory to save logs')
    parser.add_argument('--data_root', default='./data/processed_data', help='root directory for data')
    parser.add_argument('--seed', default=1, type=int, help='manual seed')
    parser.add_argument('--n_past', type=int, default=2, help='number of frames to condition on')
    parser.add_argument('--n_future', type=int, default=10, help='number of frames to predict')
    parser.add_argument('--n_eval', type=int, default=30, help='number of frames to predict at eval time')
    parser.add_argument('--num_workers', type=int, default=4, help='number of data loading threads')
    parser.add_argument('--cuda', default=False, action='store_true')  
    #parser.add_argument('--nsample', type=int, default=3, help='number of samples')
    parser.add_argument('--last_frame_skip', action='store_true', help='if true, skip connections go between frame t and frame t+t rather than last ground truth frame')
    args = parser.parse_args()
    return args

def add_border(x, color, pad=1):
    w = x.size()[1]
    nc = x.size()[0]
    px = Variable(torch.zeros(3, w+2*pad+30, w+2*pad))
    if color == 'red':
        px[0] =0.7 
    elif color == 'green':
        px[1] = 0.7
    if nc == 1:
        for c in range(3):
            px[c, pad:w+pad, pad:w+pad] = x
    else:
        px[:, pad:w+pad, pad:w+pad] = x
    return px

def main():
    args = parse_args()
    if args.cuda:
        assert torch.cuda.is_available(), 'CUDA is not available.'
        device = 'cuda'
    else:
        device = 'cpu'
    
    assert args.n_past + args.n_future <= 30 and args.n_eval <= 30

    # load model and continue training from checkpoint
    saved_model = torch.load('%s/model.pth' % args.model_dir)
    model_dir = args.model_dir
    args = saved_model['args']
    args.model_dir = model_dir
    args.log_dir = '%s/continued' % args.log_dir
    start_epoch = saved_model['last_epoch']


    print("Random Seed: ", args.seed)
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    
    print(args)

    # ------------ build the models  --------------

    frame_predictor = saved_model['frame_predictor']
    posterior = saved_model['posterior']
    decoder = saved_model['decoder']
    encoder = saved_model['encoder']
    
    # --------- transfer to device ------------------------------------
    frame_predictor.to(device)
    posterior.to(device)
    encoder.to(device)
    decoder.to(device)

    # --------- load a dataset ------------------------------------
    test_data = bair_robot_pushing_dataset(args, 'test')
    test_loader = DataLoader(test_data,
                            num_workers=args.num_workers,
                            batch_size=args.batch_size,
                            shuffle=False,
                            drop_last=True,
                            pin_memory=True)
    test_iterator = iter(test_loader)

    # --------- plot test -------------------------------------
    device = 'cuda'
    psnr_list = []
    for i, (test_seq, test_cond) in enumerate(tqdm(test_loader)):
        test_seq = test_seq.permute(1, 0, 2, 3 ,4).to(device)
        test_cond = test_cond.permute(1, 0, 2).to(device)
        pred_seq = pred(test_seq, test_cond, saved_model, args, device)
        _, _, psnr = finn_eval_seq(test_seq[args.n_past:][2:12], pred_seq[args.n_past:])
        psnr_list.append(psnr)
    ave_psnr = np.mean(np.concatenate(psnr_list))
    print(f'====================== test psnr = {ave_psnr:.5f} ========================')
    # --------- testing and make gifs ------------------------------------
    x, cond = next(test_iterator)
    x = x.permute(1, 0, 2 ,3 ,4).to(device)
    cond = cond.permute(1, 0, 2).to(device)
    frame_predictor.hidden = frame_predictor.init_hidden()
    posterior.hidden = posterior.init_hidden()
    posterior_gen = []
    posterior_gen.append(x[0])
    x_in = x[0]
    for i in range(1, args.n_eval):
        h = encoder(x_in)
        h_target = encoder(x[i])[0].detach()
        if args.last_frame_skip or i < args.n_past:
            h, skip = h
        else:
            h, _ = h
        h = h.detach()
        _, z_t, _ = posterior(h_target)
        if i < args.n_past:
            frame_predictor(torch.cat([h, cond[i-1], z_t], 1))
            posterior_gen.append(x[i])
            x_in = x[i]
        else:
            h_pred = frame_predictor(torch.cat([h, cond[i-1], z_t], 1)).detach()
            x_in = decoder([h_pred, skip]).detach()
            posterior_gen.append(x_in)
    
    nsample = 3
    ssim = np.zeros((args.batch_size, nsample, args.n_future))
    psnr = np.zeros((args.batch_size, nsample, args.n_future))
    progerss = tqdm(total=nsample)
    all_gen = []
    for s in range(nsample):
        progerss.update(1)
        gen_seq = []
        gt_seq = []
        frame_predictor.hidden = frame_predictor.init_hidden()
        posterior.hidden = posterior.init_hidden()
        x_in = x[0]
        all_gen.append([])
        all_gen[s].append(x_in)
        for i in range(1, args.n_eval):
            h = encoder(x_in)
            h_target = encoder(x[i])[0].detach()
            if args.last_frame_skip or i < args.n_past:
                h, skip = h
            else:
                h, _ = h
            h = h.detach()
            _, z_t, _ = posterior(h_target)
            if i < args.n_past:
                frame_predictor(torch.cat([h, cond[i-1], z_t], 1))
                all_gen[s].append(x[i])
                x_in = x[i]
            else:
                h_pred = frame_predictor(torch.cat([h, cond[i-1], z_t], 1)).detach()
                x_in = decoder([h_pred, skip]).detach()
                gen_seq.append(x_in)
            gt_seq.append(x[i])
            all_gen[s].append(x_in)
            
    _, ssim[:, s, :], psnr[:, s, :] = finn_eval_seq(gt_seq[args.n_past:][2:12], gen_seq[args.n_past:])### ssim
    for i in range(args.batch_size):
        gifs = [[] for _ in range(args.n_eval)]
        text = [[] for _ in range(args.n_eval)]
        mean_psnr = np.mean(psnr[i], 1)
        ordered = np.argsort(mean_psnr)
        rand_sidx = [np.random.randint(nsample) for s in range(3)]
        for t in range(args.n_eval):
            ### ground truth
            gifs[t].append(add_border(x[t][i], 'green'))
            text[t].append('Ground\ntruth')
            
            ### posterior
            if t < args.n_past:
                color = 'green'
            else:
                color = 'red'
                
            gifs[t].append(add_border(posterior_gen[t][i], color))
            text[t].append('Approx.\nposterior')
            
            ### best result
            if t < args.n_past:
                color = 'green'
            else:
                color = 'red'
            sidx = ordered[-1]
            gifs[t].append(add_border(all_gen[sidx][t][i], color))
            text[t].append('Best PSNR')
            
            ### random take 3 prediction
            for s in range(len(rand_sidx)):
                gifs[t].append(add_border(all_gen[rand_sidx[s]][t][i], color))
                text[t].append('Random\nsample %d' %(s+1))
        fname = '%s/%s_%d.gif' % (args.log_dir, 'test', 0+i) 
        save_gif_with_text(fname, gifs, text)

if __name__ == '__main__':
    main()
        
