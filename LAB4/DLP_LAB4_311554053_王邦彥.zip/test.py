import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torchvision.models as models
from dataloader import RetinopathyLoader
import os
import argparse
from torch.utils.data import DataLoader
from torch.optim import RAdam, SGD
from tqdm import tqdm
from train import test
from sklearn.metrics import confusion_matrix
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
import numpy as np

def parser_argument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str)
    parser.add_argument('--pretrained', type=bool)
    parser.add_argument('--model_number', type=int)
    return parser.parse_args()

def plot_confusion_matrix(y_true, y_pred, labels, fn):
    cm = confusion_matrix(y_true, y_pred, labels=np.arange(len(labels)), normalize='true')
    fig, ax = plt.subplots()
    sn.heatmap(cm, annot=True, ax=ax, cmap='Blues', fmt='.1f')
    ax.set_xlabel('Prediction')
    ax.set_ylabel('Ground truth')
    ax.xaxis.set_ticklabels(labels, rotation=45)
    ax.yaxis.set_ticklabels(labels, rotation=0)
    plt.title('Normalized comfusion matrix')
    plt.savefig(fn, dpi=300)


if __name__ == '__main__':
    args = parser_argument()
    
    resnet18_true = []
    resnet18_false = []
    resnet50_true = []
    resnet50_false = []
    
    model_number = str(args.model_number) + '.cpt'
    if args.model == 'resnet18':
        model = models.resnet18()
        model.fc = nn.Linear(model.fc.in_features, 5)
        if args.pretrained == True:
            model.load_state_dict(torch.load('D:\python_Practice\Anaconda3\DeepLearning\LAB4\\resnet18_True\{}'.format(model_number)))
        if args.pretrained == False:
            model.load_state_dict(torch.load('D:\python_Practice\Anaconda3\DeepLearning\LAB4\\resnet18_False\{}'.format(model_number)))
           
    if args.model == 'resnet50':
        model = models.resnet50()
        model.fc = nn.Linear(model.fc.in_features, 5)
        if args.pretrained == True:
            model.load_state_dict(torch.load('D:\python_Practice\Anaconda3\DeepLearning\LAB4\\resnet50_True\{}'.format(model_number)))
        if args.pretrained == False:
            model.load_state_dict(torch.load('D:\python_Practice\Anaconda3\DeepLearning\LAB4\\resnet50_False\{}'.format(model_number)))
    
    ### change the output at the last layer: origin=model.fc.in_feature --> 5
    model = model.to(device)
    
    batch_size = 16
    criterion = nn.CrossEntropyLoss()
    
    ### load datas
    train_data = RetinopathyLoader('.\diabetic_retinopathy_dataset', 'train')
    test_data = RetinopathyLoader('.\diabetic_retinopathy_dataset', 'test')
    
    ### build the data batch
    train_loader = DataLoader(train_data, batch_size=batch_size, num_workers=8, shuffle=True)
    test_loader = DataLoader(test_data, batch_size=batch_size, num_workers=8)
    
    ### resnet18 + pretrained
    model = models.resnet18()
    model.fc = nn.Linear(model.fc.in_features, 5)
    model = model.to(device)
    for i in tqdm(range(20)):
        model_number = str(i) + '.cpt'
        model.load_state_dict(torch.load('D:\python_Practice\Anaconda3\DeepLearning\LAB4\\resnet18_True\{}'.format(model_number)))
        ave_loss, acc, gt, pred = test(model, test_loader, criterion)
        resnet18_true.append(acc)
#     plot_confusion_matrix(gt, pred, [0, 1, 2, 3, 4], os.path.join('cm', f'resnet18_True.png'))
    print('resnet18_true: ', resnet18_true)
    ### resnet50 + pretrained
    model = models.resnet50()
    model.fc = nn.Linear(model.fc.in_features, 5)
    model = model.to(device)
    for i in tqdm(range(20)):
        model_number = str(i) + '.cpt'
        model.load_state_dict(torch.load('D:\python_Practice\Anaconda3\DeepLearning\LAB4\\resnet50_True\{}'.format(model_number)))
        ave_loss, acc, gt, pred = test(model, test_loader, criterion)
        resnet50_true.append(acc)
#     plot_confusion_matrix(gt, pred, [0, 1, 2, 3, 4], os.path.join('cm', f'resnet50_True.png'))
    print('resnet50_true: ', resnet50_true)
    ### resnet18 + not pretrained
    model = models.resnet18()
    model.fc = nn.Linear(model.fc.in_features, 5)
    model = model.to(device)
    for i in tqdm(range(20)):
        model_number = str(i) + '.cpt'
        model.load_state_dict(torch.load('D:\python_Practice\Anaconda3\DeepLearning\LAB4\\resnet18_False\{}'.format(model_number)))
        ave_loss, acc, gt, pred = test(model, test_loader, criterion)
        resnet18_false.append(acc)
#     plot_confusion_matrix(gt, pred, [0, 1, 2, 3, 4], os.path.join('cm', f'resnet18_False.png'))
    print('resnet18_false: ', resnet18_false)
    ### resnet50 + not pretrained
    model = models.resnet50()
    model.fc = nn.Linear(model.fc.in_features, 5)
    model = model.to(device)
    for i in tqdm(range(20)):
        model_number = str(i) + '.cpt'
        model.load_state_dict(torch.load('D:\python_Practice\Anaconda3\DeepLearning\LAB4\\resnet50_False\{}'.format(model_number)))
        ave_loss, acc, gt, pred = test(model, test_loader, criterion)
        resnet50_false.append(acc)
#     plot_confusion_matrix(gt, pred, [0, 1, 2, 3, 4], os.path.join('cm', f'resnet50_False.png'))   
        
    
    
    
    print('resnet50_false: ', resnet50_false)
    
    