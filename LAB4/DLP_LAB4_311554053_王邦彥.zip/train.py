# -*-utf8-*-

import torch
import torch.nn as nn
import torchvision.models as models
from dataloader import RetinopathyLoader
import os
import argparse
from torch.utils.data import DataLoader
from torch.optim import RAdam, SGD
from tqdm import tqdm
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

def train(model, train_data, optimizer, criterion, epoch_num, model_name):
    cpt_dir = 'D:\python_Practice\Anaconda3\DeepLearning\LAB4\{}'.format(model_name)
    
    print(cpt_dir)
    for epoch in range(epoch_num):
        model.train()
        epoch_loss = 0
        
        for batch_idx, (datas, labels) in enumerate(tqdm(train_data)):
            datas_tensor , labels_tensor = datas.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(datas_tensor)
            loss = criterion(outputs, labels_tensor)
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss
        
        epoch_loss /= len(train_data)
        
        print(f'epoch: {epoch:5}   Loss = {epoch_loss:.5f}')
        
        
        torch.save(model.state_dict(), os.path.join(cpt_dir, f'{epoch}.cpt'))
    return model

def test(model, test_data, criterion):
    model.eval()
    correct = 0
    ave_loss = 0
    gt, pred = [], []
    with torch.no_grad():
        for batch_idx, (datas, labels) in enumerate(test_data):
            datas_tensor, labels_tensor = datas.to(device), labels.to(device)
            outputs = model(datas_tensor)
            loss = criterion(outputs, labels_tensor)
            ave_loss += loss.item()
            
            outputs = torch.argmax(outputs, dim=1)
            correct += (outputs == labels_tensor).sum().cpu().item()
            gt += labels_tensor.detach().cpu().numpy().tolist()
            pred += outputs.detach().cpu().numpy().tolist()
            
        ave_loss /= len(test_data)
        acc = correct / len(test_data.dataset)
        return ave_loss, acc, gt, pred


def parser_argument():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str)
    parser.add_argument('--lr', default=1e-3, type=float)
    parser.add_argument('--activation', default='relu', type=str)
    parser.add_argument('--batch_size', default=16, type=int)
    parser.add_argument('--epoch', default=20, type=int)
    parser.add_argument('--pretrained', type=bool)
    parser.add_argument('--weight_dacay', default=5e-4, type=float)
    parser.add_argument('--momentum', default=0.9, type=float)
    
    
    return parser.parse_args()


if __name__ == '__main__':
    args = parser_argument()
    if args.model == 'resnet18':
        if args.pretrained == True:
            model = models.resnet18(pretrained=True)
            model_name = args.model + '_' + 'True'
        if args.pretrained == False:
            model = models.resnet18(pretrained=False)
            model_name = args.model + '_' + 'False'
           
    if args.model == 'resnet50':
        if args.pretrained == True:
            model = models.resnet50(pretrained=True)
            model_name = args.model + '_' + 'True'
        if args.pretrained == False:
            model = models.resnet50(pretraned=False)
            model_name = args.model + '_' + 'False'
    
    
    ### change the output at the last layer: origin=model.fc.in_feature --> 5
    model.fc = nn.Linear(model.fc.in_features, 5)
    model = model.to(device)
    
    weight_decay = args.weight_dacay
    lr = args.lr
    momentum = args.momentum
    activation = args.activation
    batch_size = args.batch_size
    epoch_num = args.epoch
    criterion = nn.CrossEntropyLoss()
    optimizer = SGD(model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)
    
    ### load datas
    train_data = RetinopathyLoader('.\diabetic_retinopathy_dataset', 'train')
    test_data = RetinopathyLoader('.\diabetic_retinopathy_dataset', 'test')
    
    ### build the data batch
    train_loader = DataLoader(train_data, batch_size=batch_size, num_workers=8, shuffle=True)
    test_loader = DataLoader(test_data, batch_size=batch_size, num_workers=8)
    
    ### resnet18 + pretrained
    model = train(model, train_loader, optimizer, criterion, epoch_num=epoch_num, model_name=model_name)
    
    ### resnet50 + pretrained
    model1 = models.resnet50(pretrained=True)
    model1.fc = nn.Linear(model1.fc.in_features, 5)
    model1 = model1.to(device)
    model1 = train(model1, train_loader, optimizer, criterion, epoch_num=epoch_num, model_name='resnet50_True')
    
    ### resnet18 + not pretrained
    model2 = models.resnet18(pretrained=False)
    model2.fc = nn.Linear(model2.fc.in_features, 5)
    model2 = model2.to(device)
    model2 = train(model2, train_loader, optimizer, criterion, epoch_num=epoch_num, model_name='resnet18_False')
    
    ### resnet50 + not pretrained
    model3 = models.resnet50(pretrained=False)
    model3.fc = nn.Linear(model3.fc.in_features, 5)
    model3 = model3.to(device)
    model3 = train(model3, train_loader, optimizer, criterion, epoch_num=epoch_num, model_name='resnet50_False')
    
    
    
    
    