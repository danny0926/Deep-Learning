from dataloader import read_bci_data
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.optim import RAdam, Adam, RMSprop
import argparse
import os
from nets import DeepConvNet, EEGNet, DeepConvNet1, BCIDataset

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


    
def train(model, train_data, optimizer, criterion, epoch_num, model_name):
    for epoch in range(epoch_num):
        model.train()
        epoch_loss = 0
        
        for batch_idx, (datas, labels) in enumerate(train_data):
            datas_tensor , labels_tensor = datas.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(datas_tensor)
            loss = criterion(outputs, labels_tensor)
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss
        
        epoch_loss /= len(train_data)
        
        print(f'epoch: {epoch:5}   Loss = {epoch_loss:.5f}')
        
    cpt_dir = 'D:\python_Practice\Anaconda3\DeepLearning\LAB3'
    torch.save(model.state_dict(), os.path.join(cpt_dir, f'{model_name}.cpt'))
    return model
    
def test(model, test_data, criterion):
    model.eval()
    correct = 0
    ave_loss = 0
    with torch.no_grad():
        for batch_idx, (datas, labels) in enumerate(test_data):
            datas_tensor, labels_tensor = datas.to(device), labels.to(device)
            outputs = model(datas_tensor)
            loss = criterion(outputs, labels_tensor)
            ave_loss += loss.item()
            
            outputs = torch.argmax(outputs, dim=1)
            correct += (outputs == labels_tensor).sum().item()
            
        ave_loss /= len(test_data)
        acc = correct / len(test_data.dataset)
        return ave_loss, acc

def parse_arguments():
    parser = argparse.ArgumentParser(description='DL Lab3')
    parser.add_argument('--model', type=str)
    parser.add_argument('--lr', default=1e-2, type=float)
    parser.add_argument('--activation', default='relu', type=str)
    parser.add_argument('--batch_size', default=64, type=int)
    parser.add_argument('--epoch', default=300, type=int)
    
    return parser.parse_args()
        
if __name__ == '__main__':
    args = parse_arguments()
    if args.model == 'EEGNet':
        model = EEGNet(activation=args.activation).to(device)
    if args.model == 'DeepConvNet':
        model = DeepConvNet(activation=args.activation).to(device)
    if args.model == 'DeepConvNet1':
        model = DeepConvNet1(activation=args.activation).to(device)
    lr = args.lr
    batch_size = args.batch_size
    epoch_num = args.epoch
    
    x_train, y_train, x_test, y_test = read_bci_data()
    
    train_set = BCIDataset(x_train, y_train)
    test_set = BCIDataset(x_test, y_test)
    
    train_data = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    test_data = DataLoader(test_set, batch_size=batch_size, shuffle=True)
#     print(train_data.dataset[0])
#     input()
#     print(f"test data:")
#     print('test x shape: ', x_test.shape)
#     print('test y shape: ', y_test.shape)
#     print('data loader:')
#     print(len(test_data))
#     print(test_data)
#     print('data loader dataset:')
#     print(len(test_data.dataset))
#     print(test_data.dataset)
#     input()
    model = train(
                model=model,
                train_data=train_data,
                optimizer=RAdam(model.parameters(), lr=lr),
                criterion=nn.CrossEntropyLoss(),
                epoch_num=epoch_num,
                model_name=args.model)
    ave_loss, acc = test(model=model, test_data=test_data, criterion=nn.CrossEntropyLoss())
    
    print(f'test result:\n\taverage loss = {ave_loss}\n\tacc = {acc*100:.2f}%')