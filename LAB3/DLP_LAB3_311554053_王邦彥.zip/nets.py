import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.optim import RAdam, Adam, RMSprop
import argparse
import os

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

class BCIDataset(Dataset):
    def __init__(self, data, label):
        self.data = data
        self.label = label
        
    def __getitem__(self, index):
        data = torch.tensor(self.data[index, ...], dtype=torch.float32)
        label = torch.tensor(self.label[index], dtype=torch.int64)
        return data, label
    
    def __len__(self,):
        return self.data.shape[0]


class EEGNet(nn.Module):
    def __init__(self, activation='relu'):
        super(EEGNet, self).__init__()
        if activation == 'relu':
            self.activation = nn.ReLU()
        if activation == 'lrelu':
            self.activation = nn.LeakyReLU()
        if activation == 'elu':
            self.activation = nn.ELU()
        
        ### define the layer of EEGNet
        self.firstconv = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=(1, 32), stride=(1, 1), padding=(0, 25), bias=False),
            nn.BatchNorm2d(16))
        
        self.depthwiseConv = nn.Sequential(
            nn.Conv2d(16, 32, kernel_size=(2, 8), stride=(1, 1), groups=16, bias=False),
            nn.BatchNorm2d(32),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 8), stride=(1, 4), padding=0),
            nn.Dropout(p=0.25))
        
        self.separableConv = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=(1, 32), stride=(1, 1), padding=(0, 7), bias=False),
            nn.BatchNorm2d(32),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 8), stride=(1, 8), padding=0),
            nn.Dropout(p=0.25))
        
        self.classify = nn.Sequential(
            nn.Linear(in_features=672, out_features=2, bias=True))
        
    def forward(self, x):
        out = self.firstconv(x)
        out = self.depthwiseConv(out)
        out = self.separableConv(out)
        out = self.classify(out.flatten(start_dim=1))
        
        return out
    

class DeepConvNet(nn.Module):
    def __init__(self, activation='relu'):
        super(DeepConvNet, self).__init__()
        if activation == 'relu':
            self.activation = nn.ReLU()
        if activation == 'lrelu':
            self.activation = nn.LeakyReLU()
        if activation == 'elu':
            self.activation = nn.ELU()
            
        self.layer1 = nn.Sequential(
            nn.Conv2d(1, 25, kernel_size=(1, 5)),
            nn.Conv2d(25, 25, kernel_size=(2, 1)),
            nn.BatchNorm2d(25),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 2)),
            nn.Dropout(p=0.47))
        
        self.layer2 = nn.Sequential(
            nn.Conv2d(25, 50, kernel_size=(1, 5)),
            nn.Conv2d(50, 50, kernel_size=(1, 5)),
            nn.BatchNorm2d(50),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 5)),
            nn.Dropout(p=0.47))
        
        self.layer3 = nn.Sequential(
            nn.Conv2d(50, 100, kernel_size=(1, 5)),
            nn.BatchNorm2d(100),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 5)),
            nn.Dropout(p=0.47))
        
        self.layer4 = nn.Sequential(
            nn.Conv2d(100, 300, kernel_size=(1, 5)),
            nn.BatchNorm2d(300),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 5)),
            nn.Dropout(p=0.47))
        
        self.classify = nn.Sequential(
            nn.Linear(in_features=300, out_features=100),
            nn.Linear(in_features=100, out_features=2))
        
    def forward(self, x):
        x.unsqueeze(0)
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = self.classify(out.flatten(start_dim=1))
        return out

class DeepConvNet1(nn.Module):
    def __init__(self, activation='relu'):
        super(DeepConvNet1, self).__init__()
        if activation == 'relu':
            self.activation = nn.ReLU()
        if activation == 'lrelu':
            self.activation = nn.LeakyReLU()
        if activation == 'elu':
            self.activation = nn.ELU()
            
        self.layer1 = nn.Sequential(
            nn.Conv2d(1, 25, kernel_size=(1, 5)),
            nn.Conv2d(25, 25, kernel_size=(2, 1)),
            nn.BatchNorm2d(25),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 2)),
            nn.Dropout(p=0.47))
        
        self.layer2 = nn.Sequential(
            nn.Conv2d(25, 50, kernel_size=(1, 5)),
#             nn.Conv2d(50, 50, kernel_size=(1, 5)),
            nn.BatchNorm2d(50),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 5)),
            nn.Dropout(p=0.47))
        
        self.layer3 = nn.Sequential(
            nn.Conv2d(50, 100, kernel_size=(1, 5)),
            nn.BatchNorm2d(100),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 5)),
            nn.Dropout(p=0.47))
        
        self.layer4 = nn.Sequential(
            nn.Conv2d(100, 300, kernel_size=(1, 5)),
            nn.BatchNorm2d(300),
            self.activation,
            nn.MaxPool2d(kernel_size=(1, 5)),
            nn.Dropout(p=0.47))
        
        self.classify = nn.Sequential(
            nn.Linear(in_features=300, out_features=100),
#             nn.Linear(in_features=100, out_features=2)
            )
        
    def forward(self, x):
        x.unsqueeze(0)
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = self.classify(out.flatten(start_dim=1))
        return out