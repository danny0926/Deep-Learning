from dataloader import read_bci_data
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.optim import RAdam, Adam
import argparse
import os
# from torchvision import models
# from torchsummary import summary
from nets import DeepConvNet, EEGNet, DeepConvNet1, BCIDataset
from train import test, train

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def parse_arguments():
    parser = argparse.ArgumentParser(description='DL Lab3')
    parser.add_argument('--model', type=str)
    parser.add_argument('--lr', default=1e-2, type=float)
    parser.add_argument('--activation', default='relu', type=str)
    parser.add_argument('--batch_size', default=64, type=int)
    parser.add_argument('--epoch', default=300, type=int)
    
    return parser.parse_args()
        
if __name__ == '__main__':
    args = parse_arguments()
    if args.model == 'EEGNet':
        model = EEGNet(activation=args.activation).to(device)
        cpt_path = 'D:\python_Practice\Anaconda3\DeepLearning\LAB3\stored_model\EEGNet.cpt'
    if args.model == 'DeepConvNet':
        model = DeepConvNet(activation=args.activation).to(device)
        cpt_path = 'D:\python_Practice\Anaconda3\DeepLearning\LAB3\stored_model\DeepConvNet.cpt'
    lr = args.lr
    batch_size = args.batch_size
    epoch_num = args.epoch
    
    _, _, x_test, y_test = read_bci_data()
    
    test_set = BCIDataset(x_test, y_test)
    test_data = DataLoader(test_set, batch_size=batch_size, shuffle=True)
    
    
    model.load_state_dict(torch.load(cpt_path))

    ave_loss, acc = test(model=model, test_data=test_data, criterion=nn.CrossEntropyLoss())
    
    print(f'test result:\n\taverage loss = {ave_loss}\n\tacc = {acc*100:.2f}%')
    
#     summary(model, (1, 2, 750), 64)