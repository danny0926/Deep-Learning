import matplotlib.pyplot as plt
from dataloader import read_bci_data
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.optim import RAdam, Adam, RMSprop
import argparse
import os
from nets import DeepConvNet, EEGNet, DeepConvNet1, DeepConvNet2, BCIDataset

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

def train(model, train_data, test_data, optimizer, criterion, epoch_num, model_name):
    test_accs = []
    train_accs = []
    for epoch in range(epoch_num):
        model.train()
        epoch_loss = 0
        
        for batch_idx, (datas, labels) in enumerate(train_data):
            datas_tensor , labels_tensor = datas.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(datas_tensor)
            loss = criterion(outputs, labels_tensor)
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss
        
        epoch_loss /= len(train_data)
        
        _, train_acc = test(model, train_data, criterion)
        _, test_acc = test(model, test_data, criterion)
        test_accs.append(test_acc*100)
        train_accs.append(train_acc*100)
        
        print(f'epoch: {epoch:5}   Loss = {epoch_loss:.5f}')
        
    return train_accs, test_accs
    
def test(model, test_data, criterion):
    model.eval()
    correct = 0
    ave_loss = 0
    with torch.no_grad():
        for batch_idx, (datas, labels) in enumerate(test_data):
            datas_tensor, labels_tensor = datas.to(device), labels.to(device)
            outputs = model(datas_tensor)
            loss = criterion(outputs, labels_tensor)
            ave_loss += loss.item()
            
            outputs = torch.argmax(outputs, dim=1)
            correct += (outputs == labels_tensor).sum().item()
            
        ave_loss /= len(test_data)
        acc = correct / len(test_data.dataset)
        return ave_loss, acc

if __name__ == '__main__':
    ############# this part plot the comparision between different activation functions
#     x_train, y_train, x_test, y_test = read_bci_data()
#     train_set = BCIDataset(x_train, y_train)
#     test_set = BCIDataset(x_test, y_test)
#     batch_size = 64
#     train_data = DataLoader(train_set, batch_size=batch_size, shuffle=True)
#     test_data = DataLoader(test_set, batch_size=batch_size, shuffle=True)
#     epoch_num = 300
#     lr = 1e-2
#     activations = ['relu', 'lrelu', 'elu']
#     for act in activations:
#         model = EEGNet(act).to(device)
#         train_acc, test_acc = train(
#                                     model=model,
#                                     train_data=train_data,
#                                     test_data=test_data,
#                                     optimizer=RAdam(model.parameters(), lr=lr),
#                                     criterion=nn.CrossEntropyLoss(),
#                                     epoch_num=epoch_num,
#                                     model_name='EEGNet')
#         if act == 'lrelu':
#             act='leaky_relu'
#         plt.plot(test_acc, label=act+'_test')
#         plt.plot(train_acc, label=act+'_train')
#     plt.title('Activation function comparision(EEGNet)')
#     plt.xlabel('Epoch')
#     plt.ylabel('Accuracy(%)')
#     plt.yticks([65, 70, 75, 80, 85, 90, 95, 100])
# #     plt.xlim([0, 50, 100, 150, 200, 250, 300])
# #     plt.ylim([65, 70, 75, 80, 85, 90, 95, 100])
#     plt.legend(loc='lower right')
#     plt.show()
    
    ################# this part plot the comparision between different DeepConvNet
#     x_train, y_train, x_test, y_test = read_bci_data()
#     train_set = BCIDataset(x_train, y_train)
#     test_set = BCIDataset(x_test, y_test)
#     batch_size = 64
#     train_data = DataLoader(train_set, batch_size=batch_size, shuffle=True)
#     test_data = DataLoader(test_set, batch_size=batch_size, shuffle=True)
#     epoch_num = 300
#     lr = 1e-2
    
#     model = DeepConvNet1().to(device)
#     train_acc, test_acc = train(
#                                 model=model,
#                                 train_data=train_data,
#                                 test_data=test_data,
#                                 optimizer=RAdam(model.parameters(), lr=lr),
#                                 criterion=nn.CrossEntropyLoss(),
#                                 epoch_num=epoch_num,
#                                 model_name='DeepConvNet')

#     plt.plot(test_acc, label='original_test')
#     plt.plot(train_acc, label='original_train')
    
#     batch_size = 100
#     lr = 2e-2
#     model = DeepConvNet().to(device)
#     train_acc, test_acc = train(
#                                 model=model,
#                                 train_data=train_data,
#                                 test_data=test_data,
#                                 optimizer=RAdam(model.parameters(), lr=lr),
#                                 criterion=nn.CrossEntropyLoss(),
#                                 epoch_num=epoch_num,
#                                 model_name='DeepConvNet')

#     plt.plot(test_acc, label='adjusted_test')
#     plt.plot(train_acc, label='adjusted_train')
#     plt.title('Different DeepConvNet comparison')
#     plt.xlabel('Epoch')
#     plt.ylabel('Accuracy(%)')
#     plt.yticks([65, 70, 75, 80, 85, 90, 95, 100])
# #     plt.xlim([0, 50, 100, 150, 200, 250, 300])
# #     plt.ylim([65, 70, 75, 80, 85, 90, 95, 100])
#     plt.legend(loc='lower right')
#     plt.show()